I am not responsible for any damaged cause by using this firmware on the wrong device. This Firmware is for Yuanley YS25-0801M and was provided by support@yuanley.com 

Firmware Version 3.0.2
Firmware Date    Aug 01 2024
Hardware Version V1.1